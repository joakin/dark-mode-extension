# dark mode extension

Provides one click dark mode for websites that don't have it implemented.

## License

MIT
